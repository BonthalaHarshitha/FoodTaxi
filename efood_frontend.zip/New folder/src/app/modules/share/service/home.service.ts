import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  
  private foods: any[] = [
    { foodId: 'FD-0000001', foodName: 'Grilled Chicken', action: true },
    { foodId: 'FD-0000002', foodName: 'Margherita Pizza', action: true },
    { foodId: 'FD-0000003', foodName: 'Chicken Biryani', action: true },
    { foodId: 'FD-0000004', foodName: 'Veggie Burger', action: true },
    { foodId: 'FD-0000005', foodName: 'Fish Tacos', action: true },
  ];

  getFoods(): Observable<any[]> {
    // Simulate fetching data from a backend API
    return of(this.foods);
  }
}

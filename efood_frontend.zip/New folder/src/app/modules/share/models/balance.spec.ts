import { Balance } from './balance';

describe('Balance', () => {
  it('should create an instance', () => {
    expect(new Balance()).toBeTruthy();
  });
});

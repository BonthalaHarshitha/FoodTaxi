import { Emai } from './emai';

describe('Emai', () => {
  it('should create an instance', () => {
    expect(new Emai()).toBeTruthy();
  });
});

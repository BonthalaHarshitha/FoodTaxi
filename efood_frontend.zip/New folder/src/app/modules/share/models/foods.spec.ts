import { Foods } from './foods';

describe('Foods', () => {
  it('should create an instance', () => {
    expect(new Foods()).toBeTruthy();
  });
});

import { OrderFoods } from './order-foods';

describe('OrderFoods', () => {
  it('should create an instance', () => {
    expect(new OrderFoods()).toBeTruthy();
  });
});

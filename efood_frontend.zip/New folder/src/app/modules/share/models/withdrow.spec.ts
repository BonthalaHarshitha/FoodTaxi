import { Withdrow } from './withdrow';

describe('Withdrow', () => {
  it('should create an instance', () => {
    expect(new Withdrow()).toBeTruthy();
  });
});

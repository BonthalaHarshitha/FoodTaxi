import { Component } from '@angular/core';

@Component({
  selector: 'app-withdrawn',
  templateUrl: './withdrawn.component.html',
  styleUrls: ['./withdrawn.component.css']
})
export class WithdrawnComponent {

}

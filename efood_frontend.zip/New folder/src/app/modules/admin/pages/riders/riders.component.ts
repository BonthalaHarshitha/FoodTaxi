// riders.component.ts

import { Component } from '@angular/core';

@Component({
  selector: 'app-riders',
  templateUrl: './riders.component.html',
  styleUrls: ['./riders.component.css']
})
export class RidersComponent {
  deliveries: any[] = []; // Define deliveries array with any type, adjust type as per your actual data structure

  constructor() {
    // Example: Initialize deliveries array with sample data
    this.deliveries = [
      { deliveryId: 1, status: 'On the Way', RiderName: 'Jhon', shopName: 'Pizza Hut' ,DeliveryArea:'12/10,Ammerpet,besides krishna shopping mall'},
      { deliveryId: 2, status: 'Delivered', RiderName: 'Smith', shopName: 'Burger King',DeliveryArea:'1/18,TNR Residency,Hastinapuram' },
      { deliveryId: 3, status: 'On the Way', RiderName: 'Mike', shopName: 'Chicken Hut',DeliveryArea:'19/1,Sainagar Colony,Banjara Hills' },
    ];
  }

  viewDetails(deliveryId: number) {
    // Implement logic to handle view details action
    console.log('View details for delivery ID:', deliveryId);
    // Example: Navigate to details page or show modal, etc.
  }
}

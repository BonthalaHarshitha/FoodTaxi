import { Transection } from './transection';

describe('Transection', () => {
  it('should create an instance', () => {
    expect(new Transection()).toBeTruthy();
  });
});
